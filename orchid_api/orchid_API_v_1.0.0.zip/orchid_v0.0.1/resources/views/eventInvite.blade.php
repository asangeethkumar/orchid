<p>Hi, </p>
<p>
    {{$event_creator_name}} has invited you to participate in the event "{{$event_name}}". 
    Please login or join <a href="{{$url}}">Orchid</a> to view the event.
</p>
<p style="text-align: center;"><a href="{{$url}}"><button
        style="background-color: #0c1f34;
        border: none;
        color: white;
        padding: 15px 25px;
        text-align: center;
        font-size: 16px;
        cursor: pointer;">Join Orchid</button></a></p>
<p>
    You can also download the Orchid app from PlayStore.
</p>