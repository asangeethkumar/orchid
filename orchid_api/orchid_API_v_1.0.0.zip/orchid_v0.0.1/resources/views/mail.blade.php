<p>Hi, </p>
<p>Your OTP to reset password is {{ $otp }}</p>