<p>Hi, </p>
<p>
    <?php echo e($event_creator_name); ?> has invited you to participate in the event "<?php echo e($event_name); ?>". 
    Please login or join <a href="#">Orchid</a> to accept the invitation.
</p>
<p>
    You can also download the Orchid app from PlayStore.
</p>