<?php
$event_creator_name = 'Leo';
$etAl = 'and others ';
$user_messages = [
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ],
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ],
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ],
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ],
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ],
        [
            "message_id"=> "3",
            "message"=> "Happy Birthday",
            "file_location"=> null,
            "file_name"=> null,
            "user_id"=> "23",
            "first_name"=> "Orchid RUs",
            "middle_name"=> null,
            "last_name"=> "Rus",
            "email"=> "orchidrus.webmaster@gmail.com",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/profilePictures/1553165407_9c8miHqVOI.png"
        ],
        [
            "message_id"=> "4",
            "message"=> "Hi This is a test message",
            "file_location"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/messageFiles/user/original/1551106297_E9MnOg_twitter.png",
            "file_name"=> "1551106297_E9MnOg_twitter.png",
            "user_id"=> "13",
            "first_name"=> "Leo",
            "middle_name"=> null,
            "last_name"=> null,
            "email"=> "lk@yahoo.co.in",
            "profile_picture"=> "http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/default/default_profile_pic.svg"
        ]
    ];

$arr_len = count($user_messages) + 1;
?>

<body style="background-color: #fafafa">      
<p style="text-align: center; font-size: 1.2rem;">Hi,</p>
<p style="text-align: center; font-size: 1.2rem;"><?php echo e($event_creator_name); ?> <?php echo e($etAl); ?>sent you a card from Orchid.</p>
<p style="text-align: center;"><a href="http://dameeko.com/orchid/orchid_v0.0.1/public"><button
        style="background-color: #0c1f34;
        border: none;
        color: white;
        padding: 15px 25px;
        text-align: center;
        font-size: 16px;
        cursor: pointer;">Join Orchid</button></a></p>
<table style="width: 95%; 
        border-left-style: outset;
	border-left-width: 5px;
	border-right-style: outset;
	border-right-width: 5px;
	border-bottom-style: outset;
	border-bottom-width: 5px;
        border-top-style: outset;
	border-top-width: 5px;
        background-color: #0c1f34;
        " 
        align="center" border="0">
    <tr>
        <td width="50%" style="text-align: center; background-color: #FFFFFF;">
            <table align="center" 
                   width="100%" 
                   border="0" 
                   cellpadding="10" 
                   style="display: block; height: 450px; overflow-y: auto; text-align: center;">
               <?php $__currentLoopData = $user_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr width="100%">
                        <td style="text-align: center; width: 570px;" >
                            <span style="font-size: 1.2rem;"><i><?php echo e($data['message']); ?></i></span>
                        <br />  

                        -- <?php echo e($data['first_name']); ?> --
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>            
        </td>
        <td width="50%" style="text-align: center; border-left-style: dashed;
	border-left-width: 5px; border-color: #0c1f34; background-color: #FFFFFF;">            
            <img width="95%" src="http://dameeko.com/orchid/orchid_v0.0.1/public/storage/images/cards/admin/original/1551703728_WfANEU_fancy_cake.png" />       
        </td>
    </tr>

</table> 
</body>
                        


