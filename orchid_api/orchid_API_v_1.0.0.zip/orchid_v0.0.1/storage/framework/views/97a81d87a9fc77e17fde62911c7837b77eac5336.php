<p>Hi, </p>
<p>Your OTP to reset password is <?php echo e($otp); ?></p>