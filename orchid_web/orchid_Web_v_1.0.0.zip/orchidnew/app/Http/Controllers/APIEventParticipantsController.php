<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller as Controller;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use App\EventParticipants;
use JWTFactory;
use JWTAuth;
use Validator;
use Response;

class APIEventParticipantsController extends Controller
{
    
}
