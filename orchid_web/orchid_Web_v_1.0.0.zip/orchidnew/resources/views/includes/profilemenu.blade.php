<div class="row home_menu">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 eventlist">
        <ul class="nav nav-tabs" id="eventtabs">
            <li class="activeevents"><a class="eventschange" href="{{'/profile'}}">Primary details</a></li>
            <li class="activeevents" ><a class="eventschange" href="{{'/connect-social'}}">Connect Social</a></li>
            <li class="activeevents"><a class="eventschange" href="{{'/significant-event'}}">Significant Event</a></li>
            <li class="activeevents"><a class="eventschange" href="{{'/change_password'}}">Change Password</a></li>
        </ul>
    </div>
</div>