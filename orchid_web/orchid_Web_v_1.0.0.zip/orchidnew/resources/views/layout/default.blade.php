<!DOCTYPE html>
<html lang="en">
    <head>
        @include('includes.head')
    </head>
    <body id="fontclass">

            <div id="main" class="row">
                <!-- main content -->
                <div id="content" class="col-lg-12">
                    @yield('content')
                </div>
            </div>

    </body>
</html>