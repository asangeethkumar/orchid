<div class="row home_menu">
    <div class="col-12 col-sm-12 col-md-12 col-lg-12 eventlist">
        <ul class="nav nav-tabs" id="eventtabs">
            <li class="activeevents"><a class="eventschange" href="<?php echo e('/profile'); ?>">Primary details</a></li>
            <li class="activeevents" ><a class="eventschange" href="<?php echo e('/connect-social'); ?>">Connect Social</a></li>
            <li class="activeevents"><a class="eventschange" href="<?php echo e('/significant-event'); ?>">Significant Event</a></li>
            <li class="activeevents"><a class="eventschange" href="<?php echo e('/change_password'); ?>">Change Password</a></li>
        </ul>
    </div>
</div>