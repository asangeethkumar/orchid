<?php $__env->startSection('content'); ?>
<?php if( ($agent->isDesktop()) || ($agent->isiPad()) || ($agent->match('Nexus 10')) ): ?>
    <div id="homeevents">
        <?php echo $__env->make('includes.profilemenu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="content-col" class="row">
            <div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 content-col">
                <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                    <div class="tab-content">
                        <?php if($status_code == 200): ?>
                            <!--social connect-->
                            <div id="connect_social">
                                <div id="social-content">
                                    <div class="social_connect">
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'FACEBOOK'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                       <img src="img/png/facebook.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Facebook</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'GOOGLE'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/google-plus.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Google</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'SLACK'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/slack.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Slack</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                                <?php $i=0?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($i)): ?>
                                        <?php else: ?> <?php $i=1?>
                                        <?php endif; ?>
                                        <?php if($i !=0): ?>
                                            <div id="main" class="row row_gap">
                                                <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                    <img src="img/png/slack.png" width="35" height="65">
                                                </div>
                                                <a href="<?php echo e('/connect/slack/media'); ?>">
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Slack</h6>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'TWITTER'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/twitter.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Twitter</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                                <?php $j=0?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($j)): ?>
                                        <?php else: ?> <?php $j=1?>
                                        <?php endif; ?>
                                        <?php if($j !=0): ?>
                                            <div id="main" class="row row_gap">
                                                <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                    <img src="img/png/twitter.png" width="35" height="65">
                                                </div>
                                                <a href="<?php echo e('/login/twitter'); ?>">
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Twitter</h6>
                                                    </div>
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'LINKEDIN'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/linkedin.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>LinkedIn</h6>
                                                    </div>
                                                   <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                       <img src="svg/success.svg" width="20" height="25">
                                                   </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'WHATSAPP'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/whatsapp.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>WhatsApp</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                           <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'SKYPE'): ?>
                                                <div id="main" class="row row_gap">
                                                   <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                       <img src="img/png/skype.png" width="35" height="65">
                                                   </div>
                                                   <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                       <h6>Skype</h6>
                                                   </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($connected['provider'] == 'VIBER'): ?>
                                                <div id="main" class="row row_gap">
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="img/png/viber.png" width="35" height="65">
                                                    </div>
                                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                        <h6>Viber</h6>
                                                    </div>
                                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                        <img src="svg/success.svg" width="20" height="25">
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
            <!--                        <div id="main" class="row">
                                        <div class="col-12 col-sm-offset-7 col-sm-5 col-md-offset-7 col-md-5 col-lg-offset-7 col-lg-5 save_profile">
                                            <input type="submit" name="saveprofile" class="saveprofile" value="Save"/>
                                        </div>
                                    </div>-->
                                </div>
                            </div>
                        <?php else: ?>
                            <!--social connect-->
                            <div id="connect_social">
                                <div id="social-content">
                                    <div class="social_connect">
                                        <div id="main" class="row row_gap">
                                            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                <img src="img/png/slack.png" width="35" height="65">
                                            </div>
                                            <a href="<?php echo e('/connect/slack/media'); ?>">
                                                <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                    <h6>Slack</h6>
                                                </div>
                                            </a>
                                        </div>
                                        <div id="main" class="row row_gap">
                                            <div class="col-2 col-sm-2 col-md-2 col-lg-2 col-xl-2">
                                                <img src="img/png/twitter.png" width="35" height="65">
                                            </div>
                                            <a href="<?php echo e('/login/twitter'); ?>">
                                                <div class="col-8 col-sm-8 col-md-8 col-lg-8 col-xl-8">
                                                    <h6>Twitter</h6>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>  
                    </div>
                    <!--display status-->
                    <?php if($status == ""): ?>
                    <?php endif; ?>
                    <?php if($status == 200): ?>
                        <div id="changepsd_status" class="changepsd_status">
                            <h6><?php echo e($socialMsg); ?></h6>
                            <?php unset($_SESSION['socialmsg']);?>
                        </div>
                    <?php endif; ?>
                    <?php if($status == 400): ?>
                        <div id="changepsd_status" class="changepsd_status">
                            <h6><?php echo e($socialMsg); ?></h6>
                            <?php unset($_SESSION['socialmsg']);?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php else: ?>
    <div class="row">
        <div class="col-12 col-sm-12 col-md-12 col-lg-12 content-col">
            <div class="row epd_length">
                <div class="col-2 col-sm-2 col-md-2 col-lg-2 profile_bgrnd">
                    <button class="closebtn"  onclick="document.location.href='<?php echo e('/profile'); ?>';"><img src="svg/close.svg" width="20" height="50"></button>
                </div>
                <div class="col-10 col-sm-10 col-md-10 col-lg-10 profile_bgrnd">
                    <h5 id="epd_length">Connected Social Media</h5>
                </div>
            </div>
            <?php if($status_code == 200): ?>
                <!--social connect-->
                <div id="connect_social">
                    <div class="social_connect">
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'FACEBOOK'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                       <img src="img/png/facebook.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Facebook</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'GOOGLE'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/google-plus.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Google</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($connected['provider'] == 'SLACK'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/slack.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Slack</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                                <?php $i=0?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($i)): ?>
                        <?php else: ?> <?php $i=1?>
                        <?php endif; ?>
                        <?php if($i != 0): ?>
                            <div id="main" class="row row_gap">
                                <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                    <img src="img/png/slack.png" width="35" height="65">
                                </div>
                                <a href="<?php echo e('/connect/slack/media'); ?>">
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Slack</h6>
                                    </div>
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'TWITTER'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/twitter.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Twitter</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                                <?php $j=0?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($j)): ?>
                        <?php else: ?> <?php $j=1?>
                        <?php endif; ?>
                        <?php if($j !=0): ?>
                            <div id="main" class="row row_gap">
                                <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                    <img src="img/png/twitter.png" width="35" height="65">
                                </div>
                                <a href="<?php echo e('/login/twitter'); ?>">
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Twitter</h6>
                                    </div>
                                </a>
                            </div>
                        <?php endif; ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($connected['provider'] == 'LINKEDIN'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/linkedin.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>LinkedIn</h6>
                                    </div>
                                   <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                       <img src="svg/success.svg" width="20" height="25">
                                   </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'WHATSAPP'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/whatsapp.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>WhatsApp</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                           <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'SKYPE'): ?>
                                <div id="main" class="row row_gap">
                                   <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                       <img src="img/png/skype.png" width="35" height="65">
                                   </div>
                                   <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                       <h6>Skype</h6>
                                   </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $connectedSocialMedia['output']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $connected): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($connected['provider'] == 'VIBER'): ?>
                                <div id="main" class="row row_gap">
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="img/png/viber.png" width="35" height="65">
                                    </div>
                                    <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                        <h6>Viber</h6>
                                    </div>
                                    <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                        <img src="svg/success.svg" width="20" height="25">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            <?php else: ?>
                <!--social connect-->
                <div id="connect_social">
                    <div class="social_connect">
                        <div id="main" class="row row_gap">
                            <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                <img src="img/png/slack.png" width="35" height="65">
                            </div>
                            <a href="<?php echo e('/connect/slack/media'); ?>">
                                <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                    <h6>Slack</h6>
                                </div>
                            </a>
                        </div>
                        <div id="main" class="row row_gap">
                            <div class="col-2 col-sm-2 col-md-2 col-lg-2">
                                <img src="img/png/twitter.png" width="35" height="65">
                            </div>
                            <a href="<?php echo e('/login/twitter'); ?>">
                                <div class="col-8 col-sm-8 col-md-8 col-lg-8">
                                    <h6>Twitter</h6>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?> 
        </div>
    </div>
<?php endif; ?> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.menu', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>