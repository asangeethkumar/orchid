<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body id="fontclass">
        <?php if( ($agent->isDesktop()) || ($agent->isiPad()) || ($agent->match('Nexus 10')) ): ?>
            <header id="main" class="row header_bgnd">
                <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </header>
        <?php endif; ?>
            <div id="main" class="row">
                <!-- main content -->
                <div id="content" class="col-lg-12 col-xl-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        
        <?php if( (($agent->isDesktop()) || ($agent->isiPad()) || $agent->match('Nexus 10')) == false): ?>
            <footer id="main" class="row footer">
                <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </footer>
        <?php endif; ?>

    </body>
</html>