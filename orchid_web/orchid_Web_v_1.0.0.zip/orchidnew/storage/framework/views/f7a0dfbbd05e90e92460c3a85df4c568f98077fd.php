<!DOCTYPE html>
<html lang="en">
    <head>
        <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </head>
    <body id="fontclass">

            <div id="main" class="row">
                <!-- main content -->
                <div id="content" class="col-lg-12">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>

    </body>
</html>